"""
이 클래스에서 딕셔너리로 정보 만들어서 저장해두는? 
근데이제 그걸 여기서 쪼개서 보낼건지
아님 veiw 모듈에서 쪼개서 알아서 가져갈건지는 생각해봐야할듯
✅ 3. Controller: 로직 제어 및 외부 시스템 연동 (Deadline)
### 📌 역할:

- View와 Model을 연결
- 유저 입력을 Model에 전달하고, Deadline 명령 실행
- 예외 처리 및 메시지 전달

"""
class RenderJobController():
    pass